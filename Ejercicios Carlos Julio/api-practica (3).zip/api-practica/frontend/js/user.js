// CARGAR USUARIOS
async function cargarUsuarios() {

    const usuarios = await getData("users");
    const lista = document.getElementById("listaUsuarios");

    lista.innerHTML = "";

    usuarios.forEach(u => {
        lista.innerHTML += `
        <li>
            ${u.firstName} - ${u.email}

            <button onclick="editarUsuario(${u.id}, '${u.firstName}', '${u.email}')">
                Editar
            </button>

            <button onclick="eliminarUsuario(${u.id})">
                Eliminar
            </button>
        </li>
        `;
    });
}

// CREAR USUARIO
async function crearUsuario() {

    const usuario = {
        firstName: document.getElementById("name").value,
        email: document.getElementById("email").value
    };

    if (!usuario.firstName || !usuario.email) {
        Swal.fire("Campos requeridos", "Completa todos los datos", "warning");
        return;
    }

    await createData("users", usuario);

    Swal.fire({
        icon: "success",
        title: "Usuario creado correctamente",
        timer: 1500,
        showConfirmButton: false
    });

    cargarUsuarios();
}


// ELIMINAR USUARIO
async function eliminarUsuario(id) {

    const result = await Swal.fire({
        title: "¿Eliminar usuario?",
        text: "No podrás recuperarlo",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Sí, eliminar",
        cancelButtonText: "Cancelar"
    });

    if (!result.isConfirmed) return;

    await deleteData("users", id);

    Swal.fire("Eliminado", "Usuario eliminado correctamente", "success");

    cargarUsuarios();
}

// EDITAR
async function editarUsuario(id, name, email) {

    const { value: formValues } = await Swal.fire({
        title: "Editar usuario",
        html: `
            <input id="swal-name" class="swal2-input" value="${name}">
            <input id="swal-email" class="swal2-input" value="${email}">
        `,
        showCancelButton: true,
        confirmButtonText: "Actualizar",
        preConfirm: () => {
            return {
                firstName: document.getElementById("swal-name").value,
                email: document.getElementById("swal-email").value
            };
        }
    });

    if (!formValues) return;

    await updateData("users", id, formValues);

    Swal.fire({
        icon: "success",
        title: "Usuario actualizado",
        timer: 1500,
        showConfirmButton: false
    });

    cargarUsuarios();
}

cargarUsuarios();