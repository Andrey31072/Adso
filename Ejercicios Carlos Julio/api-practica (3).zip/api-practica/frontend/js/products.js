async function cargarProductos() {

const productos = await getData("products");
const lista = document.getElementById("lista");

lista.innerHTML = "";

productos.forEach(p => {
    lista.innerHTML += `
    <li>
        ${p.title} - $${p.price}

        <button onclick="editar(${p.id},'${p.title}',${p.price})">
            Editar
        </button>

        <button onclick="eliminar(${p.id})">
            Eliminar
        </button>
    </li>
    `;
});
}

//CREAR
async function crearProducto() {

const producto = {
    title: document.getElementById("title").value,
    price: document.getElementById("price").value
};

await createData("products", producto);

Swal.fire({
    icon: "success",
    title: "Producto creado",
    text: "Se guardó correctamente",
    timer: 1500,
    showConfirmButton: false
});

cargarProductos();
}

//ELIMINAR
async function eliminar(id) {

const result = await Swal.fire({
    title: "¿Eliminar producto?",
    text: "Esta acción no se puede deshacer",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar"
});

if (!result.isConfirmed) return;

await deleteData("products", id);

Swal.fire({
    icon: "success",
    title: "Eliminado",
    text: "Producto eliminado correctamente",
    timer: 1500,
    showConfirmButton: false
});

cargarProductos();
}

// EDITAR
async function editar(id, title, price) {

const { value: formValues } = await Swal.fire({
    title: "Editar producto",
    html: `
        <input id="swal-title" class="swal2-input" placeholder="Nombre" value="${title}">
        <input id="swal-price" class="swal2-input" placeholder="Precio" value="${price}">
    `,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Actualizar",
    preConfirm: () => {
        return {
            title: document.getElementById("swal-title").value,
            price: document.getElementById("swal-price").value
        };
    }
});

if (!formValues) return;

await updateData("products", id, formValues);

Swal.fire({
    icon: "success",
    title: "Actualizado",
    text: "Producto actualizado correctamente",
    timer: 1500,
    showConfirmButton: false
});

cargarProductos();
}

cargarProductos();






/* async function cargarProductos() {

const productos = await getData("products");
const lista = document.getElementById("lista");

lista.innerHTML = "";

productos.forEach(p => {
    lista.innerHTML += `
    <li>
        ${p.title} - $${p.price}

    <button onclick="editar(${p.id},'${p.title}',${p.price})">
        Editar
    </button>

    <button onclick="eliminar(${p.id})">
        Eliminar
    </button>
    </li>
    `;
    }
    );
}

async function crearProducto() {

const producto = {
    title: document.getElementById("title").value,
    price: document.getElementById("price").value
};

await createData("products", producto);

alert("Producto creado exitosamente :D");
cargarProductos();
}

async function eliminar(id) {

if (!confirm("¿Eliminar producto?")) return;

await deleteData("products", id);
cargarProductos();
}

async function editar(id, title, price) {

const nuevoTitulo = prompt("Nuevo nombre:", title);
const nuevoPrecio = prompt("Nuevo precio:", price);

const producto = {
    title: nuevoTitulo,
    price: nuevoPrecio
};

await updateData("products", id, producto);

alert("Producto actualizado exitosamente pelado");
cargarProductos();
}

cargarProductos(); */