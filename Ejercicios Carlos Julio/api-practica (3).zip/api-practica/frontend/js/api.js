const API_URL = "http://localhost:3000";

// GET
async function getData(endpoint) {
const res = await fetch(`${API_URL}/${endpoint}`);
return await res.json();
}

// POST
async function createData(endpoint, data) {
await fetch(`${API_URL}/${endpoint}`, {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify(data)
            }
        );
}

// DELETE
async function deleteData(endpoint, id) {
    await fetch(`${API_URL}/${endpoint}/${id}`, {
    method: "DELETE"
        }
    );     
}

// UPDATE
async function updateData(endpoint, id, data) {
    await fetch(`${API_URL}/${endpoint}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
        }
    );
}