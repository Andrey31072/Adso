const fs = require("fs");

const products = JSON.parse(fs.readFileSync("./products.json", "utf-8"));
const users = JSON.parse(fs.readFileSync("./users.json", "utf-8"));
const posts = JSON.parse(fs.readFileSync("./posts.json", "utf-8"));
const carts = JSON.parse(fs.readFileSync("./carts.json", "utf-8"));

const db = {
  products: products.products || products,
  users: users.users || users,
  posts: posts.posts || posts,
  carts: carts.carts || carts
};

fs.writeFileSync("db.json", JSON.stringify(db, null, 2), "utf-8");

console.log("db.json creado correctamente");