/* 
	exercise name: Net Force
	Descripción: calculate net force
	Autor: Kevin Andrey
	Fecha: march 16th 2025 
*/

let forceOne = 10;  
let forceTwo = 5;
let forceThree = -3;
let netForce = forceOne + forceTwo + forceThree;

console.log("netForce: " + netForce);
