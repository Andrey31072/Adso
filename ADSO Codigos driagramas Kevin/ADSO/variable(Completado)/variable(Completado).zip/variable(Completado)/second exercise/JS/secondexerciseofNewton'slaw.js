/*
	Name exercise: Force 
	Description: Newton's first law
	Author: Stiven lopez
	Date: March 16th, 2025
*/

let force=5;
let acceleration=26; 
let inertia;
let mass;

 mass=force * acceleration;
 inertia=mass

console.log("inertia", inertia);