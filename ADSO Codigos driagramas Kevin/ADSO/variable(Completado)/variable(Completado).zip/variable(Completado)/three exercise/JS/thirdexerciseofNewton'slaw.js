/*
	Name exercise: mass
	Description: third exercise of Newton's law
	Author: Kevin Andrey 
	Date: March 16th, 2025
*/

let mass = 156;
let force = 5;
let acceleration;

acceleration = force / mass;

console.log("acceleration:", acceleration);
