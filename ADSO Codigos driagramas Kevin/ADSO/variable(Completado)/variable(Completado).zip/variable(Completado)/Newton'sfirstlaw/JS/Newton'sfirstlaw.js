/*
	Name exercise:first 
	Description: Newton's first law
	Author: Kevin Andrey
	Date: March 16th, 2025
*/

let mass=10;
let acceleration=5; 
let force;

 force=mass * acceleration;

console.log("force", force);