/*
    Name exercise: Weight
    Description: calculate weight through formula.
    Author: Kevin Andrey 
    Date: March 16th, 2025
*/

let mass=17;
let gravity=9.8;
let weight;

    weight=mass * gravity

    console.log(" weight",  weight)