/*
	Name exercise: weighted of three grades
	Description:  Calculate grade point average
	Autor: Kevin Andrey 
	Date: march 15th 2025
*/

let gradeOne=4.5;
let gradeTwo=2.5;
let gradeThree=3.0;
let fullGradeOne;
let fullGradeTwo;
let fullGradeThree;
let weighted;

fullGradeOne=gradeOne*0.3;
fullGradeTwo=gradeTwo*0.3;
fullGradeThree=gradeThree*0.4;

weighted=fullGradeOne+fullGradeTwo+fullGradeThree;
console.log("Weighted Grades: "+weighted);
