/*
	 name exercise: first
	 description: my first exercise of js with variables
	 autor: Kevin Andrey
	 Date: 15th of march of 2025
*/

let numberOne = 12;
let numberTwo = 10;

let addition;

addition = numberOne + numberTwo;

console.log("Result Addition is:" + addition);