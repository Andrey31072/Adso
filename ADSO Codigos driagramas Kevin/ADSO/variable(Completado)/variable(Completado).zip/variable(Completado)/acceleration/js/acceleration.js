/* 
  Name exercise:acceleration  
  Description: calculate the acceleration of a car
  Autor: kevin Andrey 
  Date: march 19th 2025
*/

let mass= 20;
let force= 4;

let  acceleration= (mass/force);

console.log("Acceleration:" + acceleration);
 