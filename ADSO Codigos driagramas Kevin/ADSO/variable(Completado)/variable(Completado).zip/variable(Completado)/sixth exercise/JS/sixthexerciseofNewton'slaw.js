/*
Name exercise: four exercises
Description: four exercises
    Author: Stiven Lopez
    Date: March 16th, 2025
*/

let forceAction = 17;  
let forceReaction = 9;
let less;

less = forceAction + forceReaction;  

console.log("less:", less);  
