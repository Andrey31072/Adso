/*
	Name exercise: avarag three age
	Description: calculates avarege of age
	Autor: Kevin Andrey 
	Date: march 15th 2025
*/

let ageOne=28;
let ageTwo=18;
let ageThree=18; 

if(ageOne >=18){
	console.log("is adult");
} else {
	console.log("is child");
}

if(ageTwo >=18){
        console.log("is adult");
} else {
	console.log("is child");
}

if(ageThree >=18){
        console.log("is adult");
} else {
	console.log("is child");
}

 let addition= ageOne + ageTwo + ageThree;
console.log("Result Addition is:" + addition);

let average;

average = addition/3
console.log("result average is: " + average);
if(average >= 18){
	console.log("is adult");
} else {
	console.log("is child");
}