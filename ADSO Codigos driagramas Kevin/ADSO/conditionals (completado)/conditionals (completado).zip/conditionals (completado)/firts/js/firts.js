/*
 name exercise: first
 description: my first exercise of js with variables
 autor: Andrey Gómez
 Date: 15 of march of 2025
*/

let gradeOne = 4.9;
let gradeTwo = 4.2;
let gradeThree = 3.7; 

let addition;

addition = gradeOne + gradeTwo + gradeThree;

let average;

average = addition/3;

console.log("Result average is:" + addition/3);