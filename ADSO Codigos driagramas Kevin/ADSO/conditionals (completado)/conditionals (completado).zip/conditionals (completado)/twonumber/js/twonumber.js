/*
	Name exercise: Two numbers
	Description: Two Numbers
	Autor: AndresMC
	Date: march 15th 2025
*/

let numberOne=12;
let numberTwo=15;

if(numberOne==numberTwo){
	console.log("Are equals");
}
else if(numberOne>numberTwo){
	console.log("Number One is greater");
}
else{
	console.log("Number Two is greater");
}




