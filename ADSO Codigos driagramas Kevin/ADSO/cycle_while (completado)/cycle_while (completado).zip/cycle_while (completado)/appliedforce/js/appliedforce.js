/*
	Name exercise: appliedforce
	Description: The program will ask for an applied force (F) and display its reaction force.
        Autor: Kevin Andrey 
	Date: march 20th 2025
*/

let appliedforce =10;
let counter = 0;
let reationforce = 0;
let forcetotal = 0;
let force = 20;

while (force !== 0) {
  appliedforce += force;
reationforce = -appliedforce;
  forcetotal += force;
  counter++ ;
 
  console.log("reationforce:" + reationforce);
  console.log("Forcetotal: " + forcetotal);
  console.log("Counter: " + counter);
 force = (0);

}







 




     



    
