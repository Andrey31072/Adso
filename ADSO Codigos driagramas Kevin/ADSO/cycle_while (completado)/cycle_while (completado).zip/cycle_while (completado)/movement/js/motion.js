/*
	Name exercise: number1
	Description: calculates the gravitational potential energy of an object
	Autor: Kevin Andrey
	Date: march 20th 2025
*/
let distance= 10;
let mass= 5;
let speed= 0.1;
let time= 10;
let appliedForce= 20;
let counter= 0;
   
       while(counter < time) {
            
        counter ++; 
let force= appliedForce;

       if (force ===0){
}
         let acceleration= force/ mass;
                speed += acceleration;
          distance +=  speed;

 console.log ("Acceleration:" + acceleration); 
console.log ("Distance:" + distance); 
 console.log ("Counter:" + counter); 
console.log ("Speed:" + speed);

}





   
 
 
