/*
	Name exercise: number1
	Description: calculates the gravitational potential energy of an object
	Autor: Kevin Andrey
	Date: march 20th 2025
*/

let number= 5;
let counter= 0;

while(counter < 5) {
      counter++;
     
let produt= number * counter;
   console.log("number * counter:" + produt);
} 
 

