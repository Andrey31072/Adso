/*
	Name exercise: multiplication table 
	Description: multiplication table in codes
	Autor: Kevin Andrey
	Date: March 19th, 2025
*/

let number = 5;

for (let counter = 1; counter <= 5; counter++) {
    let product = number * counter;
    console.log(`${number} x ${counter} = ${product}`);
}